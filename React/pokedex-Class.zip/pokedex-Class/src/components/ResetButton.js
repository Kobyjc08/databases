/*import React, { component } from 'react';

class ResetButton extends Component {
    componentWill
}
*/